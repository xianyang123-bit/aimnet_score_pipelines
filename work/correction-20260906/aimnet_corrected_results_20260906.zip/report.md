# Corrected AIMNet interaction-energy and score results

Completed 2026-09-06. This report supersedes the previous T3/CASF AIMNet ranking summaries for the recalculated datasets.

## What was corrected

The default installed neighbor-list execution path failed repeatability, batching, and geometric-invariance checks. The process-local aimnet_safe_calculator.py uses explicit PyTorch pairwise distances instead. Five scoring scripts now import this calculator, and sparse energy evaluators explicitly retain float64 for energy subtraction. The wrapper also restores full-range Coulomb neighbors for the legacy full_embedded checkpoint; the installed calculator had implicitly limited that path to 15 angstrom. Installed third-party packages were not edited.

The checkpoints, input geometries, formal-charge reader, CPCM refinement settings (300 steps, torsion force constant 1), and local minimization settings (1000 steps) were retained. This is a numerical correction, not a switch from the older checkpoint to AIMNet2-2025.

| Consumer | Recalculated outputs |
|---|---|
| aimnet_t3_interaction.py | T3 per-target aimnet_interaction.csv |
| aimnet_casf_interaction.py | CASF all-pose energies, best-pose CSV/SDF, and summaries |
| aimnet_chunk_smoke.py | 250-ligand AIMNet2-2025 interaction scores |
| aimnet_score_chunk.py | Alternate chunk scorer patched for future runs |
| aimnet2_composite_smoke.py | Gas-phase ligand term, CPCM refinement/minimization, desolvation, strain, composite energies and ranks |
| aggregate_t3_active_affinity.py | T3 per-ligand, per-target and L1-L4 summaries |
| analyze_casf_target.py / aggregate_casf_multi24.py | CASF rank comparisons, per-pocket metrics and aggregate summaries |

dependency_inventory.json lists matching lines in the dependent scripts and job files. updated_files.json records every promoted destination with before/after SHA-256 hashes. Obsolete original script backups were deleted at the user's request. Outdated result backups were deleted at the user's request; comparison tables and before/after hashes remain.

## T3 affinity-ranking results

Recomputed 917 scored ligands. The 96 target/layer cases contain three pre-existing empty pose files (L3/P18564, L4/Q15726, and L4/Q8TDU9); those cases had no previous score tables and remain unscored. No replacement poses were generated.

| Layer | Targets | Ligands | Old composite Spearman | Corrected composite Spearman | Old interaction Spearman | Corrected interaction Spearman | Smina Spearman |
|---|---:|---:|---:|---:|---:|---:|---:|
| L1 | 24 | 231 | -0.0229 | -0.0079 | 0.0408 | 0.0252 | 0.0302 |
| L2 | 24 | 236 | 0.0663 | 0.0609 | 0.0446 | 0.0787 | 0.0945 |
| L3 | 23 | 230 | 0.0007 | -0.0529 | -0.0411 | -0.0283 | 0.1069 |
| L4 | 21 | 210 | -0.0941 | -0.0744 | -0.0689 | -0.0588 | -0.0104 |

Spearman values are means across targets against experimental pAffinity. Table counts include only targets with defined correlations; one additional scored L4 target (10 ligands) has an undefined correlation and is excluded from these means. This active-only pilot has no decoys and no EF1 metric. The original bootstrap confidence intervals and other metrics are recomputed in t3/aggregate_summary.json.

Across matched ligands, the median absolute composite-energy change is 11.528 kcal/mol; the maximum is 1228.906 kcal/mol.

## CASF reranking results

Recomputed 47,896 pose energies across 24 pockets, then selected best poses and recomputed 480 composite scores. The separate earlier 3ebp run was also recalculated.

178 of 480 selected best poses changed. casf_pose_changes.csv records each ligand and its old/new pose index.

| Metric | Previous | Corrected |
|---|---:|---:|
| Mean shortlist interaction EF1 | 1.7778 | 1.6111 |
| Mean shortlist composite EF1 | 1.1389 | 1.3056 |
| Mean composite actives in top 5 | 1.4583 | 1.2083 |
| Mean composite actives in top 10 | 2.7083 | 2.4583 |
| Converged composite optimizations | 468.0000 | 469.0000 |

These are metrics within the previously retrieved 20-ligand shortlist (the 1% cutoff selects one ligand). The full 285-ligand retrieval ranking is unchanged; these are not full-library rescoring metrics.

## 250-ligand T3 smoke test

| Metric | Previous | Corrected |
|---|---:|---:|
| Composite EF1 | 0.0000 | 0.0000 |
| Composite AUROC | 0.5749 | 0.3990 |
| Converged optimizations | 202 | 204 |

This is the same nonrandom B4RNM9 first chunk (58 actives, 192 decoys), not a full-library evaluation. Its interaction model remains AIMNet2-2025; the gas-phase correction remains the saved older checkpoint.

## Validation and limits

- Earlier 14-complex/two-model checks: 28/28 passed with explicit neighbors, with a maximum paired-run invariance discrepancy of 0.053 kcal/mol.
- Independent direct TorchScript comparison using independently constructed NumPy neighbor matrices on three T3 systems: all passed; maximum interaction-energy difference 0.001847 kcal/mol.
- arithmetic_validation.json verifies finite score terms and the composite-energy sum. Matching and change comparisons use ligand identities rather than row positions.
- Protein protonation/charge assumptions are retained. Numerical consistency does not validate these chemical assumptions or establish DFT/affinity accuracy.
- Some ligand optimizations do not converge within the existing iteration limits; counts and flags are retained in the corrected outputs.
- The reference neighbor implementation is quadratic in system size and explicitly rejects periodic cells. It was validated for these nonperiodic benchmark reruns.
- The exact underlying defect in the installed default path remains unresolved. Correct neighbor sets at finite cutoffs and a failed contiguous-buffer-only experiment indicate that a simple buffer-contiguity change is insufficient.
- External hiqbind.csv reference predictions were not overwritten: their exact preparation/checkpoint provenance has not been established.

## Historical experiments not regenerated

legacy_experiments_not_recomputed.json lists small exploratory CSVs whose precise refinement settings or supplied interaction energies are not fully recorded. Those eight outdated experimental CSVs were deleted at the user's request. The canonical T3/CASF outputs and the complete 250-ligand smoke test are regenerated.

## Reproducibility

Canonical package: /home/xianyang/aimnet2_score_pipelines/work. Corrected run: its correction-20260906 directory. rerun_*_correction.py contains the exact arguments. Current scripts are included in the scripts directory; obsolete backups and one-time migration code were deleted. Model hashes and input/output update hashes are included.

Slurm runs: 10339751 (final T3), 10339752 (final CASF), 10339765 (final smoke), 10339716 (successful independent NumPy-neighbor validation). The superseded first-pass 15-angstrom result files have been deleted.

Cleanup: outdated result backups, baseline result copies, prior debug result files, and eight historical experiment CSVs were deleted on 2026-09-06. Current numerical tables and input files were preserved. See cleanup_log.json.

Code cleanup: removed obsolete script backups, failed experiments, one-time migration/report scripts, and generated bytecode. Current scoring, rerun, validation, preparation and analysis code is retained. See code_cleanup_log.json.
